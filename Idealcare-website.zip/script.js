const menu = document.querySelector(".menu-toggle");
const links = document.querySelector(".nav-links");
menu?.addEventListener("click", () => {
  const open = links.classList.toggle("open");
  menu.setAttribute("aria-expanded", open);
});
document.querySelectorAll(".nav-links a").forEach(a => a.addEventListener("click", () => links.classList.remove("open")));

const date = document.getElementById("date");
if (date) date.min = new Date().toISOString().split("T")[0];

document.getElementById("year").textContent = new Date().getFullYear();

document.getElementById("appointmentForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const name = document.getElementById("name").value.trim();
  const phone = document.getElementById("phone").value.trim();
  const dateValue = document.getElementById("date").value;
  const time = document.getElementById("time").value;
  const service = document.getElementById("service").value;
  const location = document.getElementById("location").value.trim();
  const message = document.getElementById("message").value.trim();

  const readableDate = new Date(dateValue + "T00:00:00").toLocaleDateString("en-KE", {
    weekday: "long", year: "numeric", month: "long", day: "numeric"
  });

  const text =
`*IDEALCARE APPOINTMENT REQUEST*

Patient/Client: ${name}
Phone: ${phone}
Preferred date: ${readableDate}
Preferred time: ${time}
Service: ${service}
Location/area: ${location}
Additional information: ${message || "None"}

Please confirm availability and appointment details.`;

  window.open("https://wa.me/254707228627?text=" + encodeURIComponent(text), "_blank");
});
